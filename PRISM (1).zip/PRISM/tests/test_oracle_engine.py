from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_oracle

events = run_simulation(seed=42)

features = extract_features(events)

source_ip = features[
    features["label"] == "SUSPICIOUS"
].iloc[0]["source_ip"]

result = run_oracle(
    events,
    features,
    source_ip,
    budget=3
)

print("\n========== PRISM ORACLE ENGINE ==========")

print("Target IP:", result["source_ip"])
print("Total Evidence:", result["total_evidence"])
print("Investigation Budget:", result["budget"])

print("\n--- Ranked Evidence ---")

for item in result["ranked_evidence"]:
    print(
        item["evidence_type"],
        "| Utility:", item["utility"],
        "| Cost:", item["cost"],
        "| Efficiency:", item["efficiency"],
        "| Group:", item["redundancy_group"]
    )

print("\n--- Selected Evidence ---")

for item in result["selected_evidence"]:
    print(item["description"])

print("\n--- Investigation Summary ---")

print("Total Cost:", result["total_cost"])
print("Total Utility:", result["total_utility"])
print("Remaining Budget:", result["remaining_budget"])