from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_oracle

events = run_simulation(seed=42)
features = extract_features(events)

source_ip = features[
    features["label"] == "SUSPICIOUS"
].iloc[0]["source_ip"]

print("Testing IP:", source_ip)

budgets = [0, 2, 3, 5]

for budget in budgets:

    result = run_oracle(
        events,
        features,
        source_ip,
        budget=budget
    )

    print("\nBudget:", budget)
    print("Selected:", len(result["selected_evidence"]))
    print("Total Cost:", result["total_cost"])
    print("Total Utility:", result["total_utility"])
    print("Remaining:", result["remaining_budget"])

    assert result["total_cost"] <= budget
    assert result["remaining_budget"] >= 0

print("\nALL BUDGET TESTS PASSED!")