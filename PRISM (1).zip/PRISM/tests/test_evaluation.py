from modules.mirror.simulator import run_simulation

from modules.trace.feature_extraction import extract_features

from modules.trace.ml_model import PRISMAnomalyDetector

from modules.trace.model_evaluation import evaluate_model


# Generate dataset
events = run_simulation()

# Extract features
features = extract_features(events)

# Train model
detector = PRISMAnomalyDetector()

detector.fit(features)

# Generate predictions
predictions = detector.predict(features)

# Evaluate model
results = evaluate_model(
    features,
    predictions
)

print("\n========== PRISM MODEL EVALUATION ==========")

print(
    "\nAccuracy:",
    round(results["accuracy"] * 100, 2), "%"
)

print(
    "Precision:",
    round(results["precision"] * 100, 2), "%"
)

print(
    "Recall:",
    round(results["recall"] * 100, 2), "%"
)

print(
    "F1 Score:",
    round(results["f1_score"] * 100, 2), "%"
)

print("\nConfusion Matrix:")

print(results["confusion_matrix"])

print("\nClassification Report:")

print(results["classification_report"])

print("\n========== EVALUATION COMPLETED ==========")