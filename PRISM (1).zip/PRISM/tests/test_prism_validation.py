from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features

from modules.oracle.evaluation import (
    prepare_investigations,
    evaluate_greedy
)

from modules.oracle.global_optimizer import (
    optimize_global_budget
)


# Test different simulation seeds
seeds = [42, 100, 2026]

# Test different investigation budgets
budgets = [0, 5, 10, 20, 50]

total_tests = 0
passed_tests = 0

print("\n========== PRISM SYSTEM VALIDATION ==========")

for seed in seeds:

    events = run_simulation(seed=seed)
    features = extract_features(events)

    investigations = prepare_investigations(
        events,
        features
    )

    for budget in budgets:

        total_tests += 1

        greedy = evaluate_greedy(
            investigations,
            budget
        )

        global_result = optimize_global_budget(
            investigations,
            budget
        )

        # Validation checks
        assert len(events) == 1000

        assert features["source_ip"].nunique() == 100

        assert greedy["total_cost"] <= budget

        assert global_result["total_cost"] <= budget

        assert global_result["remaining_budget"] >= 0

        assert (
            global_result["total_utility"]
            >= greedy["total_utility"]
        )

        # Check redundancy constraints
        for investigation in global_result[
            "selected_investigations"
        ]:

            groups = [
                item["redundancy_group"]
                for item in investigation["selected_evidence"]
            ]

            assert len(groups) == len(set(groups))

        passed_tests += 1

        print(
            f"PASS | Seed: {seed} | "
            f"Budget: {budget} | "
            f"Global Utility: {global_result['total_utility']}"
        )


print("\n========== FINAL VALIDATION ==========")

print("Total Tests:", total_tests)
print("Passed Tests:", passed_tests)
print("Failed Tests:", total_tests - passed_tests)

print("\nPRISM SYSTEM VALIDATION COMPLETED!")