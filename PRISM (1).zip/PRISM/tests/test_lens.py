from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_multi_ip_oracle
from modules.lens.decision_explainer import explain_decision

events = run_simulation(seed=42)

features = extract_features(events)

result = run_multi_ip_oracle(
    events,
    features,
    budget=20
)

print("\n========== PRISM LENS ==========")

for investigation in result["selected_investigations"]:

    explanation = explain_decision(investigation)

    print("\nIP:", explanation["source_ip"])
    print("Priority:", explanation["priority"])
    print("Risk Level:", explanation["risk_level"])

    print(
        "Selected Evidence:",
        explanation["selected_evidence_count"]
    )

    for item in explanation["explanations"]:

        print("\nEvidence:", item["evidence_type"])
        print("Reason:", item["reason"])
        print("Utility:", item["utility"])
        print("Cost:", item["cost"])
        print("Decision:", item["selection_reason"])