from modules.mirror.simulator import run_simulation

from modules.trace.feature_extraction import extract_features

from modules.trace.ml_model import PRISMAnomalyDetector

from modules.trace.model_evaluation import evaluate_model


# Generate independent training dataset
train_events = run_simulation(seed=42)

# Generate independent testing dataset
test_events = run_simulation(seed=100)

# Extract behavioural features
train_features = extract_features(train_events)

test_features = extract_features(test_events)

# Initialize model
detector = PRISMAnomalyDetector()

# Train only on training dataset
detector.fit(train_features)

# Predict unseen testing dataset
predictions = detector.predict(test_features)

# Evaluate predictions
results = evaluate_model(
    test_features,
    predictions
)

print("\n========== PRISM GENERALIZATION TEST ==========")

print("\nTraining IPs:", len(train_features))

print("Testing IPs:", len(test_features))

print("\nIndependent Test Results:")

print(
    "Accuracy:",
    round(results["accuracy"] * 100, 2), "%"
)

print(
    "Precision:",
    round(results["precision"] * 100, 2), "%"
)

print(
    "Recall:",
    round(results["recall"] * 100, 2), "%"
)

print(
    "F1 Score:",
    round(results["f1_score"] * 100, 2), "%"
)

print("\nConfusion Matrix:")

print(results["confusion_matrix"])

print("\nClassification Report:")

print(results["classification_report"])

print("\n========== TEST COMPLETED ==========")