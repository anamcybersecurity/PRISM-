import pandas as pd

from modules.mirror.simulator import run_simulation

# Generate synthetic events
events = run_simulation()

# Convert events into DataFrame
df = pd.DataFrame(events)

print("\n========== PRISM DATASET VALIDATION ==========")

print("\n1. Total Events:")
print(len(df))

print("\n2. Unique IP Addresses:")
print(df["source_ip"].nunique())

print("\n3. Scenario Distribution:")
print(df["scenario"].value_counts())

print("\n4. Label Distribution:")
print(df["label"].value_counts())

print("\n5. Missing Values:")
print(df.isnull().sum())

print("\n6. Dataset Preview:")
print(df.head())

print("\n========== VALIDATION COMPLETED ==========")