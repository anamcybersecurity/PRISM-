from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.evaluation import evaluate_oracle

# Generate synthetic dataset
events = run_simulation(seed=42)

# Extract TRACE features
features = extract_features(events)

# Run evaluation
results = evaluate_oracle(
    events,
    features,
    budget=20
)

print("\n========== ORACLE PERFORMANCE EVALUATION ==========")

print("Suspicious IPs:", results["total_suspicious_ips"])
print("Investigation Budget:", results["budget"])

for algorithm in ["greedy", "global"]:

    metrics = results[algorithm]

    print(f"\n--- {algorithm.upper()} OPTIMIZATION ---")

    for key, value in metrics.items():
        print(f"{key}: {value}")

print("\n--- FINAL COMPARISON ---")

print(
    "Global Utility Improvement:",
    results["utility_improvement_percent"],
    "%"
)