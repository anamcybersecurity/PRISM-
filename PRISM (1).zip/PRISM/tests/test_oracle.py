from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.evidence_generator import generate_evidence
from modules.oracle.evidence_ranking import rank_evidence
from modules.oracle.budget_optimizer import optimize_budget

# Generate synthetic events
events = run_simulation(seed=42)

# Extract TRACE features
features = extract_features(events)

# Select one IP for investigation
source_ip = features[
    features["label"] == "SUSPICIOUS"
].iloc[0]["source_ip"]

# Generate evidence
evidence = generate_evidence(events, features, source_ip)

ranked = rank_evidence(evidence)

print("\nORACLE EVIDENCE RANKING")

for item in ranked:
    print(
        item["evidence_type"],
        "| Utility:", item["utility"],
        "| Cost:", item["cost"],
        "| Efficiency:", item["efficiency"]
    )

print("Selected IP:", source_ip)
print("Total Evidence Generated:", len(evidence))

# Set investigation budget
budget = 3

# Optimize evidence selection
result = optimize_budget(ranked, budget)

print("\nORACLE BUDGET OPTIMIZATION")
print("Investigation Budget:", budget)
print("Total Cost:", result["total_cost"])
print("Total Utility:", result["total_utility"])
print("Remaining Budget:", result["remaining_budget"])

print("\nSELECTED EVIDENCE")

for item in result["selected_evidence"]:
    print(item["evidence_type"], "| Utility:", item["utility"])

for item in evidence:
    print(item)