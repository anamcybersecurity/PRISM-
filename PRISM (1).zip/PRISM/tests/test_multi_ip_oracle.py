from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_multi_ip_oracle

# Generate synthetic dataset
events = run_simulation(seed=42)

# Extract IP-level features
features = extract_features(events)

# Run multi-IP ORACLE
result = run_multi_ip_oracle(
    events,
    features,
    budget=20
)

print("\n========== PRISM MULTI-IP ORACLE ==========")

print("Suspicious IPs:", result["total_suspicious_ips"])
print("Investigated IPs:", result["investigated_ips"])

print("\n--- Investigation Results ---")

for item in result["selected_investigations"]:

    print("\nIP:", item["source_ip"])
    print("Priority:", item["priority"])
    print("Cost:", item["total_cost"])
    print("Utility:", item["total_utility"])

    for evidence in item["selected_evidence"]:
        print("Evidence:", evidence["evidence_type"])

print("\n--- Global Budget Summary ---")

print("Total Budget:", result["total_budget"])
print("Total Cost:", result["total_cost"])
print("Remaining Budget:", result["remaining_budget"])
print("Total Utility:", result["total_utility"])