import pandas as pd

from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features


# Generate synthetic events
events = run_simulation()

# Extract behavioural features
features = extract_features(events)

print("\n========== TRACE FEATURE VALIDATION ==========")

print("\n1. Total IPs Analysed:")
print(len(features))

print("\n2. Feature Columns:")
print(features.columns.tolist())

print("\n3. Dataset Shape:")
print(features.shape)

print("\n4. Missing Values:")
print(features.isnull().sum())

print("\n5. Behavioural Feature Preview:")
print(features.head())

print("\n6. Statistical Summary:")
print(features.describe())

print("\n7. Total Events Verification:")
print(features["total_events"].sum())

print("\n========== VALIDATION COMPLETED ==========")