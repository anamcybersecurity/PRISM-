from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features

from modules.replay.strategy_runner import run_replay
from modules.replay.comparison_engine import compare_strategies
from modules.replay.replay_visualizer import generate_replay_timeline


# Generate synthetic dataset
events = run_simulation(seed=42)

# Extract behavioural features
features = extract_features(events)

# Run replay
replay = run_replay(
    events,
    features,
    budget=20
)

# Compare strategies
comparison = compare_strategies(replay)

# Generate investigation timeline
timeline = generate_replay_timeline(replay)


print("\n========== PRISM REPLAY ==========")

print("Suspicious IPs:", replay["total_suspicious_ips"])
print("Investigation Budget:", replay["budget"])

print("\n========== STRATEGY COMPARISON ==========")

for strategy, metrics in comparison["comparison"].items():

    print(f"\n{strategy}")

    for key, value in metrics.items():
        print(key, ":", value)


print("\nGlobal Utility Improvement:",
      comparison["global_utility_improvement"], "%")


print("\n========== INVESTIGATION TIMELINE ==========")

for strategy, steps in timeline.items():

    print("\n", strategy)

    for step in steps:

        print(
            "Step:", step["step"],
            "| IP:", step["source_ip"],
            "| Cost:", step["cumulative_cost"],
            "| Utility:", step["cumulative_utility"]
        )