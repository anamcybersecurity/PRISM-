
import pandas as pd

from modules.ingestion.normalizer import normalize_events

sample_data = pd.DataFrame({
    "src_ip": ["192.0.2.10", "198.51.100.20"],
    "event": ["failed_login", "port_scan"],
    "level": ["high", "medium"],
    "bytes": [100, 500]
})

result = normalize_events(sample_data)

print("NORMALIZED DATA:")
print(result)

print("\nTOTAL RECORDS:", len(result))
print("SOURCE:", result["data_source"].unique())