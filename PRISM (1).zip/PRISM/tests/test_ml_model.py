import pandas as pd

from modules.mirror.simulator import run_simulation

from modules.trace.feature_extraction import extract_features

from modules.trace.ml_model import PRISMAnomalyDetector


# Generate synthetic events
events = run_simulation()

# Extract behavioural features
features = extract_features(events)

# Initialize ML model
detector = PRISMAnomalyDetector()

# Train Isolation Forest
detector.fit(features)

# Generate predictions
results = detector.predict(features)

print("\n========== PRISM ML MODEL RESULTS ==========")

print("\nTotal IPs Analysed:")
print(len(results))

print("\nPrediction Distribution:")
print(results["prediction"].value_counts())

print("\nAnomaly Detection Results:")
print(results)

print("\nAnomaly Scores:")
print(results["anomaly_score"].describe())

print("\n========== ML TEST COMPLETED ==========")