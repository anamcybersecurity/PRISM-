from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_multi_ip_oracle

from modules.lens.investigation_report import (
    generate_investigation_report,
    print_investigation_report
)

events = run_simulation(seed=42)

features = extract_features(events)

budget = 20

result = run_multi_ip_oracle(
    events,
    features,
    budget=budget
)

report = generate_investigation_report(
    result["selected_investigations"],
    budget
)

print_investigation_report(report)