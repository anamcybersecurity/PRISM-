from modules.mirror.simulator import run_simulation
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_oracle
from modules.lens.evidence_explainer import explain_evidence

events = run_simulation(seed=42)
features = extract_features(events)

source_ip = features[
    features["label"] == "SUSPICIOUS"
].iloc[0]["source_ip"]

result = run_oracle(
    events,
    features,
    source_ip,
    budget=3
)

explanations = explain_evidence(
    result["ranked_evidence"],
    result["selected_evidence"],
    result["remaining_budget"] + result["total_cost"]
)

print("\n========== LENS EVIDENCE EXPLANATION ==========")

for item in explanations:

    print("\nEvidence:", item["evidence_type"])
    print("Status:", item["status"])
    print("Utility:", item["utility"])
    print("Cost:", item["cost"])
    print("Reason:", item["reason"])