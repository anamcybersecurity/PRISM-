import streamlit as st
import pandas as pd
import json
from datetime import datetime

from modules.ingestion.file_loader import load_uploaded_file
from modules.ingestion.normalizer import normalize_events
from modules.ingestion.real_trace_analysis import analyze_imported_events
from modules.ingestion.real_oracle_analysis import run_imported_oracle
from modules.ingestion.real_replay_analysis import run_imported_replay

from modules.mirror.simulator import run_simulation
from modules.trace.anomaly_detection import analyze_events
from modules.trace.feature_extraction import extract_features
from modules.oracle.selection_engine import run_multi_ip_oracle
from modules.lens.decision_explainer import explain_decision
from modules.lens.investigation_report import generate_investigation_report
from modules.replay.strategy_runner import run_replay
from modules.replay.comparison_engine import compare_strategies
from modules.replay.replay_visualizer import generate_replay_timeline


# --------------------------------------------------
# PAGE CONFIGURATION + VISUAL THEME
# --------------------------------------------------
st.set_page_config(
    page_title="PRISM | Security Operations",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');

:root {
    --bg: #080d18;
    --panel: #101a2b;
    --panel2: #142238;
    --line: rgba(148, 163, 184, .16);
    --text: #e8f0fb;
    --muted: #8fa3bd;
    --cyan: #38d6e8;
    --blue: #5688ff;
    --green: #36d399;
}
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp {
    background:
      radial-gradient(ellipse at 15% 0%, rgba(36, 91, 160, .20), transparent 35%),
      radial-gradient(ellipse at 90% 8%, rgba(31, 179, 190, .10), transparent 30%),
      var(--bg);
    color: var(--text);
}
[data-testid="stHeader"] { background: rgba(8,13,24,.82); }
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1728 0%, #0a1220 100%);
    border-right: 1px solid var(--line);
}
[data-testid="stSidebar"] > div { padding-top: 1.4rem; }
h1, h2, h3 { font-family: 'Space Grotesk', sans-serif !important; color: #f2f7ff; }
h1 { letter-spacing: -1.5px; }
p, label, .stMarkdown { color: var(--text); }
small, [data-testid="stCaptionContainer"] { color: var(--muted) !important; }
.block-container { padding-top: 1.8rem; padding-bottom: 2.5rem; max-width: 1500px; }
div[data-testid="stMetric"] {
    background: linear-gradient(145deg, rgba(20,34,56,.96), rgba(14,25,42,.96));
    border: 1px solid var(--line);
    border-radius: 14px;
    padding: 16px 18px;
    box-shadow: 0 8px 26px rgba(0,0,0,.16);
}
[data-testid="stMetricLabel"] { color: #9db0c9 !important; font-size: .82rem; }
[data-testid="stMetricValue"] { color: #f4f8ff !important; font-family: 'Space Grotesk', sans-serif; }
[data-testid="stMetricDelta"] { color: var(--green) !important; }
.stTabs [data-baseweb="tab-list"] {
    gap: 8px; background: rgba(16,26,43,.72);
    border: 1px solid var(--line); padding: 7px;
    border-radius: 13px;
}
.stTabs [data-baseweb="tab"] {
    height: 42px; border-radius: 9px; color: #a9bad0;
    padding: 0 17px; font-weight: 600;
}
.stTabs [aria-selected="true"] {
    background: linear-gradient(90deg, rgba(54,125,220,.30), rgba(42,194,207,.16));
    color: #f5fbff !important;
}
.stButton > button, .stDownloadButton > button {
    border: 1px solid rgba(56,214,232,.38);
    background: linear-gradient(100deg, #1769a8, #147f91);
    color: white; border-radius: 10px; font-weight: 700;
    min-height: 42px; transition: .2s ease;
}
.stButton > button:hover, .stDownloadButton > button:hover {
    border-color: var(--cyan); color: white;
    box-shadow: 0 0 18px rgba(56,214,232,.18);
    transform: translateY(-1px);
}
.stTextInput input, .stNumberInput input {
    background: #101c2e !important; color: #e8f0fb !important;
    border-color: var(--line) !important;
}
[data-testid="stDataFrame"], [data-testid="stTable"] {
    border: 1px solid var(--line); border-radius: 12px; overflow: hidden;
}
div[data-testid="stExpander"] {
    background: rgba(16,26,43,.68);
    border: 1px solid var(--line); border-radius: 11px;
}
hr { border-color: var(--line); }
.prism-hero {
    background: linear-gradient(115deg, rgba(20,43,73,.96), rgba(12,45,58,.86));
    border: 1px solid rgba(79,180,220,.25);
    border-radius: 18px; padding: 25px 28px; margin-bottom: 20px;
    box-shadow: 0 14px 40px rgba(0,0,0,.20);
}
.prism-kicker {
    color: #5de0ed; text-transform: uppercase; letter-spacing: 2.2px;
    font-size: .72rem; font-weight: 700; margin-bottom: 8px;
}
.prism-title {
    font-family: 'Space Grotesk', sans-serif; font-size: 2.25rem;
    line-height: 1.1; font-weight: 700; color: #f4f9ff;
}
.prism-subtitle { color: #a9bdd4; font-size: 1rem; margin-top: 9px; }
.status-chip {
    display: inline-block; padding: 6px 11px; border-radius: 999px;
    background: rgba(54,211,153,.10); color: #62e5b1;
    border: 1px solid rgba(54,211,153,.25); font-size: .75rem; font-weight: 700;
}
.section-label {
    color: #5bd9e8; font-size: .72rem; font-weight: 700;
    letter-spacing: 1.7px; text-transform: uppercase; margin-bottom: 5px;
}
.module-card {
    background: linear-gradient(145deg, rgba(20,34,56,.95), rgba(12,23,39,.95));
    border: 1px solid var(--line); border-radius: 13px;
    padding: 16px; min-height: 112px;
}
.module-card b { color: #edf6ff; font-size: .95rem; }
.module-card span { color: #8fa3bd; font-size: .8rem; }
.footer-note { color: #6f849e; font-size: .75rem; text-align: center; padding-top: 18px; }
</style>
""", unsafe_allow_html=True)


def section_heading(kicker, title, description=None):
    st.markdown(f'<div class="section-label">{kicker}</div>', unsafe_allow_html=True)
    st.subheader(title)
    if description:
        st.caption(description)


def safe_metric_value(value, suffix=""):
    if value is None:
        return "—"
    return f"{value}{suffix}"


def build_imported_lens_report(oracle_result):
    """Create explainable summaries from imported ORACLE selections."""
    investigations = oracle_result.get("selected_investigations", [])
    explanations = []
    for investigation in investigations:
        evidence_explanations = []
        for evidence in investigation.get("selected_evidence", []):
            evidence_explanations.append({
                "evidence_type": evidence.get("evidence_type", "UNKNOWN"),
                "reason": evidence.get("description", "No description available."),
                "selection_reason": (
                    "Selected by the budget optimizer as part of the highest-utility "
                    "evidence combination that fits the configured budget."
                ),
                "utility": evidence.get("utility", 0),
                "cost": evidence.get("cost", 0),
            })
        explanations.append({
            "source_ip": investigation.get("source_ip"),
            "risk_level": investigation.get("priority", "UNRANKED"),
            "risk_score": investigation.get("risk_score", 0),
            "selected_evidence_count": len(evidence_explanations),
            "total_cost": investigation.get("total_cost", 0),
            "total_utility": investigation.get("total_utility", 0),
            "explanations": evidence_explanations,
        })

    total_budget = int(oracle_result.get("total_budget", 0))
    total_cost = int(oracle_result.get("total_cost", 0))
    return {
        "report_type": "Imported security log investigation",
        "method": "TRACE rule-based indicators + ORACLE 0/1 knapsack optimization",
        "investigated_ips": len(investigations),
        "candidate_ips": int(oracle_result.get("candidate_ips", 0)),
        "total_budget": total_budget,
        "total_cost": total_cost,
        "remaining_budget": int(oracle_result.get("remaining_budget", max(0, total_budget-total_cost))),
        "budget_utilization": round(total_cost / total_budget * 100, 2) if total_budget else 0.0,
        "total_utility": int(oracle_result.get("total_utility", 0)),
        "investigations": explanations,
        "limitations": [
            "Risk scores and evidence utility/cost values are prototype heuristics.",
            "Selections are not confirmed threat verdicts or measured real-world information gain.",
            "Only fields and event types present in the uploaded data are used.",
        ],
    }


# --------------------------------------------------
# SIDEBAR: CONTROL CENTER
# --------------------------------------------------
with st.sidebar:
    st.markdown("## 🛡️ PRISM")
    st.caption("SECURITY OPERATIONS CONSOLE")
    st.markdown('<span class="status-chip">● SIMULATION MODE</span>', unsafe_allow_html=True)
    st.markdown("---")

    st.markdown("### Investigation Controls")
    seed = st.number_input("Simulation seed", min_value=0, value=42, step=1)
    budget = st.slider("Investigation budget", min_value=0, max_value=100, value=20)
    st.caption("Budget units are prototype investigation-cost units.")

    run_button = st.button("▶  Run investigation", use_container_width=True)

    st.markdown("---")
    st.markdown("### Data Source")
    data_mode = st.radio(
        "Choose input mode",
        ["Synthetic Data", "Import CSV / JSON"],
        index=0
    )

    uploaded_file = None
    load_import_button = False

    if data_mode == "Import CSV / JSON":
        uploaded_file = st.file_uploader(
            "Upload security logs",
            type=["csv", "json"],
            help="Upload an authorized CSV or JSON security log file."
        )
        load_import_button = st.button(
            "⬆  Load and normalize",
            use_container_width=True
        )

    st.markdown("---")
    st.markdown("### Intelligence Modules")
    st.markdown("🪞 **MIRROR**  ·  Event simulation")
    st.markdown("🔍 **TRACE**  ·  Behaviour analysis")
    st.markdown("🧠 **ORACLE**  ·  Evidence optimization")
    st.markdown("🔬 **LENS**  ·  Explainable decisions")
    st.markdown("📊 **REPLAY**  ·  Strategy evaluation")
    st.markdown("---")
    st.caption("PRISM build · Hackathon prototype")


# --------------------------------------------------
# HERO HEADER
# --------------------------------------------------
st.markdown("""
<div class="prism-hero">
  <div class="prism-kicker">Cybersecurity intelligence platform</div>
  <div class="prism-title">PRISM <span style="color:#4ed9e8">/</span> Security Operations</div>
  <div class="prism-subtitle">Proactive Reasoning and Intelligence for Security Monitoring</div>
  <div style="margin-top:16px"><span class="status-chip">● SYNTHETIC ENVIRONMENT</span></div>
</div>
""", unsafe_allow_html=True)


# --------------------------------------------------
# IMPORTED DATA INGESTION
# --------------------------------------------------
if data_mode == "Import CSV / JSON" and load_import_button:
    if uploaded_file is None:
        st.warning("Please select a CSV or JSON file first.")
    else:
        try:
            with st.spinner("Loading and normalizing the uploaded security logs..."):
                raw_import_df = load_uploaded_file(uploaded_file)
                normalized_import_df = normalize_events(raw_import_df)

                st.session_state["imported_raw_df"] = raw_import_df
                st.session_state["imported_df"] = normalized_import_df
                st.session_state["imported_filename"] = uploaded_file.name

            st.success("File loaded and normalized successfully.")
        except Exception as exc:
            st.error(f"Unable to import this file: {exc}")

if data_mode == "Import CSV / JSON":
    if "imported_df" in st.session_state:
        imported_df = st.session_state["imported_df"].copy()

        section_heading(
            "Data ingestion",
            "Imported security telemetry",
            "Imported records are analyzed by TRACE using supported event types. ORACLE / LENS / REPLAY remain synthetic-only until their imported-data adapters are validated."
        )

        st.markdown(
            f'<span class="status-chip">● IMPORTED DATA</span> '
            f'<span style="color:#9db0c9">File: {st.session_state.get("imported_filename", "uploaded file")}</span>',
            unsafe_allow_html=True
        )

        total_rows = len(imported_df)
        unique_sources = imported_df["source_ip"].nunique() if "source_ip" in imported_df else 0
        missing_cells = int(imported_df.isna().sum().sum())
        total_cells = int(imported_df.shape[0] * imported_df.shape[1])
        missing_pct = round((missing_cells / total_cells) * 100, 2) if total_cells else 0

        imp1, imp2, imp3, imp4 = st.columns(4)
        imp1.metric("Imported records", f"{total_rows:,}")
        imp2.metric("Unique source IPs", f"{unique_sources:,}")
        imp3.metric("Columns", f"{len(imported_df.columns):,}")
        imp4.metric("Missing cells", f"{missing_pct}%")

        st.markdown("#### Normalized event records")
        st.caption("Column names are standardized where supported. Missing source fields remain empty; PRISM does not invent real event values.")
        st.dataframe(imported_df, use_container_width=True, height=380)

        st.markdown("#### Data quality overview")
        quality_df = pd.DataFrame({
            "Column": imported_df.columns,
            "Missing values": [int(imported_df[col].isna().sum()) for col in imported_df.columns],
            "Data type": [str(imported_df[col].dtype) for col in imported_df.columns]
        })
        st.dataframe(quality_df, use_container_width=True, hide_index=True)

        download_col, info_col = st.columns([1, 2])
        with download_col:
            st.download_button(
                "⬇  Download normalized CSV",
                imported_df.to_csv(index=False).encode("utf-8"),
                "prism_normalized_import.csv",
                "text/csv"
            )
        with info_col:
            st.info(
                "TRACE uses rule-based indicators from recognized imported event types. "
                "ORACLE, LENS and REPLAY are not yet connected to imported records."
            )

        st.markdown("---")
        st.markdown("#### TRACE · Imported log behavioural analysis")
        st.caption(
            "Supported event mappings include failed_login, successful_login, port_scan and file_access. "
            "Risk scores are prototype indicators, not confirmed threat verdicts."
        )
        if st.button("🔍 Run TRACE analysis on imported logs", use_container_width=True):
            try:
                imported_trace_features, imported_trace_results = analyze_imported_events(imported_df)
                st.session_state["imported_trace_features"] = imported_trace_features
                st.session_state["imported_trace_results"] = imported_trace_results
                st.success("TRACE analysis completed for imported records.")
            except Exception as exc:
                st.error(f"TRACE could not analyze this file: {exc}")

        if "imported_trace_results" in st.session_state:
            risk_df = st.session_state["imported_trace_results"]
            feature_df = st.session_state["imported_trace_features"]
            t1, t2, t3, t4 = st.columns(4)
            t1.metric("High risk indicators", int((risk_df["risk_level"] == "HIGH").sum()))
            t2.metric("Medium risk indicators", int((risk_df["risk_level"] == "MEDIUM").sum()))
            t3.metric("Low risk indicators", int((risk_df["risk_level"] == "LOW").sum()))
            t4.metric("Insufficient data", int((risk_df["risk_level"] == "INSUFFICIENT DATA").sum()))

            left_trace, right_trace = st.columns(2)
            with left_trace:
                st.markdown("**Behavioural feature matrix**")
                st.dataframe(feature_df, use_container_width=True, hide_index=True)
            with right_trace:
                st.markdown("**Source IP risk indicators**")
                st.dataframe(risk_df, use_container_width=True, hide_index=True)
                if not risk_df.empty:
                    chart_df = risk_df.set_index("source_ip")["risk_score"].sort_values(ascending=False)
                    st.bar_chart(chart_df)
            st.caption(
                "TRACE scoring uses failed-login, port-scan and file-access counts. "
                "Missing measurements are not treated as zero evidence; event types outside the supported mapping "
                "are not included in these behaviour counts."
            )

            st.markdown("---")
            st.markdown("#### ORACLE · Imported evidence optimization")
            st.caption(
                "ORACLE selects evidence from TRACE-positive source IPs under the configured budget. "
                "Evidence utility and cost are prototype heuristics."
            )
            if st.button("🧠 Run ORACLE on imported logs", use_container_width=True):
                try:
                    imported_oracle = run_imported_oracle(
                        feature_df, risk_df, imported_df, budget=budget
                    )
                    st.session_state["imported_oracle_result"] = imported_oracle
                    st.success("ORACLE evidence optimization completed for imported records.")
                except Exception as exc:
                    st.error(f"ORACLE could not optimize imported evidence: {exc}")

            if "imported_oracle_result" in st.session_state:
                oracle_imp = st.session_state["imported_oracle_result"]
                oi1, oi2, oi3, oi4 = st.columns(4)
                oi1.metric("Candidate IPs", oracle_imp["candidate_ips"])
                oi2.metric("Investigated IPs", oracle_imp["investigated_ips"])
                oi3.metric("Selected utility", oracle_imp["total_utility"])
                oi4.metric("Budget used", f'{oracle_imp["total_cost"]} / {oracle_imp["total_budget"]}')
                st.progress(
                    min(1.0, oracle_imp["budget_utilization"] / 100) if budget else 0.0,
                    text=f'{oracle_imp["remaining_budget"]} budget units remaining'
                )
                imported_oracle_rows = []
                for investigation in oracle_imp["selected_investigations"]:
                    imported_oracle_rows.append({
                        "Source IP": investigation["source_ip"],
                        "Priority": investigation["priority"],
                        "TRACE risk score": investigation["risk_score"],
                        "Evidence items": len(investigation["selected_evidence"]),
                        "Cost": investigation["total_cost"],
                        "Heuristic utility": investigation["total_utility"],
                    })
                st.markdown("**Selected imported investigations**")
                if imported_oracle_rows:
                    st.dataframe(pd.DataFrame(imported_oracle_rows), use_container_width=True, hide_index=True)
                else:
                    st.info("No evidence fit the current budget. Increase the budget or inspect TRACE indicators.")
                st.markdown("**Selected evidence details**")
                for investigation in oracle_imp["selected_investigations"]:
                    with st.expander(f'{investigation["source_ip"]} · {investigation["priority"]} priority'):
                        for evidence in investigation["selected_evidence"]:
                            st.markdown(f'**{evidence["evidence_type"]}**')
                            st.write(evidence["description"])
                            st.caption(f'Utility: {evidence["utility"]} · Cost: {evidence["cost"]}')
                st.caption(oracle_imp["utility_note"])

                st.markdown("---")
                st.markdown("#### LENS · Imported investigation explanations")
                st.caption(
                    "LENS explains why ORACLE selected each available evidence item. "
                    "These explanations describe prototype decisions, not confirmed attacks."
                )
                if st.button("🔬 Generate LENS explanations", use_container_width=True):
                    st.session_state["imported_lens_report"] = build_imported_lens_report(oracle_imp)
                    st.success("LENS explanations generated for imported investigations.")

                if "imported_lens_report" in st.session_state:
                    imported_lens = st.session_state["imported_lens_report"]
                    li1, li2, li3, li4 = st.columns(4)
                    li1.metric("IPs explained", imported_lens["investigated_ips"])
                    li2.metric("Evidence items", sum(
                        item["selected_evidence_count"] for item in imported_lens["investigations"]
                    ))
                    li3.metric("Heuristic utility", imported_lens["total_utility"])
                    li4.metric("Budget utilization", f'{imported_lens["budget_utilization"]}%')

                    st.markdown("**Decision explanations by source IP**")
                    if not imported_lens["investigations"]:
                        st.info("ORACLE selected no evidence, so there are no imported investigations to explain.")
                    for investigation in imported_lens["investigations"]:
                        with st.expander(
                            f'{investigation["source_ip"]} · {investigation["risk_level"]} priority'
                        ):
                            d1, d2, d3 = st.columns(3)
                            d1.metric("TRACE risk score", investigation["risk_score"])
                            d2.metric("Selected evidence", investigation["selected_evidence_count"])
                            d3.metric("Investigation cost", investigation["total_cost"])
                            for item in investigation["explanations"]:
                                st.markdown(f'**{item["evidence_type"]}**')
                                st.write(item["reason"])
                                st.caption(
                                    f'Selection rationale: {item["selection_reason"]} '
                                    f'· Utility: {item["utility"]} · Cost: {item["cost"]}'
                                )
                                st.markdown("---")

                    st.markdown("**Complete imported investigation report**")
                    st.json(imported_lens, expanded=False)
                    st.download_button(
                        "⬇  Download imported LENS report (JSON)",
                        json.dumps(imported_lens, indent=4, default=str),
                        "prism_imported_lens_report.json",
                        "application/json",
                        use_container_width=True,
                    )

                st.markdown("---")
                st.markdown("#### REPLAY · Imported strategy evaluation")
                st.caption(
                    "Compares a greedy utility-per-cost baseline with ORACLE's global "
                    "0/1-knapsack selection on the same imported evidence pool."
                )
                if st.button("📊 Run REPLAY comparison on imported logs", use_container_width=True):
                    try:
                        st.session_state["imported_replay_result"] = run_imported_replay(oracle_imp)
                        st.success("REPLAY strategy comparison completed for imported records.")
                    except Exception as exc:
                        st.error(f"REPLAY could not compare strategies: {exc}")

                if "imported_replay_result" in st.session_state:
                    imported_replay = st.session_state["imported_replay_result"]
                    comparison = imported_replay["comparison"]
                    greedy = comparison["GREEDY"]
                    global_result = comparison["GLOBAL"]
                    rp1, rp2, rp3, rp4 = st.columns(4)
                    rp1.metric("Greedy utility", greedy["total_utility"])
                    rp2.metric("Global utility", global_result["total_utility"])
                    rp3.metric("Global utility uplift", f'{imported_replay["global_utility_improvement"]}%')
                    rp4.metric("Global evidence items", global_result["evidence_items"])

                    st.markdown("**Strategy scorecard**")
                    scorecard = pd.DataFrame([
                        {"Strategy": name, "Investigated IPs": result["investigated_ips"],
                         "Evidence items": result["evidence_items"], "Total cost": result["total_cost"],
                         "Remaining budget": result["remaining_budget"], "Utility": result["total_utility"],
                         "Budget utilization": result["budget_utilization"]}
                        for name, result in comparison.items()
                    ]).set_index("Strategy")
                    st.dataframe(scorecard, use_container_width=True)

                    chart_a, chart_b = st.columns(2)
                    with chart_a:
                        st.markdown("**Utility comparison**")
                        st.bar_chart(scorecard["Utility"])
                    with chart_b:
                        st.markdown("**Budget utilization**")
                        st.bar_chart(scorecard["Budget utilization"])

                    for strategy_name, result in comparison.items():
                        with st.expander(f'{strategy_name} strategy · {result["evidence_items"]} evidence items'):
                            timeline_df = pd.DataFrame(result["timeline"])
                            if timeline_df.empty:
                                st.info("No evidence selected under this budget.")
                            else:
                                st.dataframe(timeline_df, use_container_width=True, hide_index=True)
                                st.line_chart(timeline_df.set_index("step")["cumulative_utility"])
                    st.caption(imported_replay["note"])
                    st.download_button(
                        "⬇  Download imported REPLAY comparison (JSON)",
                        json.dumps(imported_replay, indent=4, default=str),
                        "prism_imported_replay_comparison.json",
                        "application/json",
                        use_container_width=True,
                    )
    else:
        st.info(
            "Choose a CSV or JSON security log file in the sidebar, then click **Load and normalize**. "
            "Use only data from systems you own or are authorized to monitor."
        )


# --------------------------------------------------
# RUN COMPLETE PIPELINE
# --------------------------------------------------
if run_button and data_mode == "Synthetic Data":
    try:
        with st.spinner("PRISM is processing the simulated security environment..."):
            events = run_simulation(seed=int(seed))
            trace_features, trace_results = analyze_events(events)
            oracle_features = extract_features(events)

            oracle_result = run_multi_ip_oracle(
                events, oracle_features, budget=budget
            )

            lens_report = generate_investigation_report(
                oracle_result["selected_investigations"], budget
            )

            replay_result = run_replay(
                events, oracle_features, budget=budget
            )
            replay_comparison = compare_strategies(replay_result)
            replay_timeline = generate_replay_timeline(replay_result)

            st.session_state["events"] = events
            st.session_state["trace_features"] = trace_features
            st.session_state["trace_results"] = trace_results
            st.session_state["oracle_features"] = oracle_features
            st.session_state["oracle_result"] = oracle_result
            st.session_state["lens_report"] = lens_report
            st.session_state["replay_result"] = replay_result
            st.session_state["replay_comparison"] = replay_comparison
            st.session_state["replay_timeline"] = replay_timeline
            st.session_state["last_run_seed"] = int(seed)
            st.session_state["last_run_budget"] = int(budget)
            st.session_state["last_run_time"] = datetime.now().strftime("%d %b %Y · %H:%M:%S")

        st.success("Investigation completed. Dashboard data refreshed.")
    except Exception as exc:
        st.error(f"PRISM pipeline could not complete: {exc}")
        st.exception(exc)


# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------
if data_mode == "Synthetic Data" and "events" in st.session_state:
    events = st.session_state["events"]
    df = pd.DataFrame(events)
    trace_features = st.session_state["trace_features"]
    trace_results = st.session_state["trace_results"]
    oracle_result = st.session_state["oracle_result"]
    lens_report = st.session_state["lens_report"]
    replay_result = st.session_state["replay_result"]
    replay_comparison = st.session_state["replay_comparison"]
    replay_timeline = st.session_state["replay_timeline"]

    # Top-level command/status row
    status_col1, status_col2, status_col3 = st.columns([1.3, 1, 1])
    with status_col1:
        st.markdown('<span class="status-chip">● PIPELINE COMPLETE</span>', unsafe_allow_html=True)
    with status_col2:
        st.caption(f"Last run: {st.session_state.get('last_run_time', '—')}")
    with status_col3:
        st.caption(f"Seed {st.session_state.get('last_run_seed', seed)}  ·  Budget {st.session_state.get('last_run_budget', budget)}")

    section_heading("Command overview", "Investigation snapshot", "A consolidated view of the current synthetic investigation run.")
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Security events", f"{len(df):,}")
    k2.metric("Unique source IPs", f"{df['source_ip'].nunique():,}")
    k3.metric("Suspicious IPs", oracle_result["total_suspicious_ips"])
    k4.metric("IPs investigated", oracle_result["investigated_ips"])

    st.markdown("---")

    mirror_tab, trace_tab, oracle_tab, lens_tab, replay_tab = st.tabs([
        "🪞  MIRROR", "🔍  TRACE", "🧠  ORACLE", "🔬  LENS", "📊  REPLAY"
    ])

    # MIRROR
    with mirror_tab:
        section_heading("01 / Environment", "MIRROR · Synthetic event simulation",
                        "Generate and inspect the security events used by the investigation pipeline.")
        a, b, c = st.columns(3)
        a.metric("Total events", f"{len(df):,}")
        normal_count = int((df["label"] == "NORMAL").sum()) if "label" in df else 0
        suspicious_count = int((df["label"] == "SUSPICIOUS").sum()) if "label" in df else 0
        b.metric("Normal events", f"{normal_count:,}")
        c.metric("Suspicious events", f"{suspicious_count:,}")

        st.markdown("#### Event telemetry")
        search_col, filter_col = st.columns([1.2, 1])
        with search_col:
            ip_query = st.text_input("Filter by source IP", placeholder="e.g. 192.0.2.10", key="mirror_ip_filter")
        with filter_col:
            event_types = sorted(df["event_type"].dropna().astype(str).unique()) if "event_type" in df else []
            selected_types = st.multiselect("Event types", event_types, default=[], key="mirror_event_filter")

        view_df = df.copy()
        if ip_query:
            view_df = view_df[view_df["source_ip"].astype(str).str.contains(ip_query, case=False, na=False)]
        if selected_types:
            view_df = view_df[view_df["event_type"].astype(str).isin(selected_types)]
        st.caption(f"Showing {len(view_df):,} of {len(df):,} generated records.")
        st.dataframe(view_df, use_container_width=True, height=340)

        chart1, chart2 = st.columns(2)
        with chart1:
            st.markdown("#### Event type distribution")
            st.bar_chart(df["event_type"].value_counts())
        with chart2:
            st.markdown("#### Scenario distribution")
            st.bar_chart(df["scenario"].value_counts())
        chart3, chart4 = st.columns(2)
        with chart3:
            st.markdown("#### Severity distribution")
            st.bar_chart(df["severity"].value_counts())
        with chart4:
            st.markdown("#### Label distribution")
            if "label" in df:
                st.bar_chart(df["label"].value_counts())
        st.download_button(
            "⬇  Export security logs (CSV)",
            df.to_csv(index=False).encode("utf-8"),
            "prism_security_logs.csv",
            "text/csv"
        )

    # TRACE
    with trace_tab:
        section_heading("02 / Behavioural intelligence", "TRACE · Anomaly and risk analysis",
                        "Review aggregated source-IP features and the behavioural risk output.")
        st.markdown("#### Risk overview")
        risk_df = pd.DataFrame(trace_results)
        if not risk_df.empty and "risk_level" in risk_df.columns:
            high_risk = int((risk_df["risk_level"] == "HIGH").sum())
            medium_risk = int((risk_df["risk_level"] == "MEDIUM").sum())
            low_risk = int((risk_df["risk_level"] == "LOW").sum())
        else:
            high_risk = medium_risk = low_risk = 0
        r1, r2, r3 = st.columns(3)
        r1.metric("High risk IPs", high_risk)
        r2.metric("Medium risk IPs", medium_risk)
        r3.metric("Low risk IPs", low_risk)

        if "risk_score" in risk_df.columns and "source_ip" in risk_df.columns:
            st.markdown("#### Source IP risk scores")
            risk_chart = risk_df.set_index("source_ip")["risk_score"].sort_values(ascending=False)
            st.bar_chart(risk_chart.head(20))
        left, right = st.columns(2)
        with left:
            st.markdown("#### Behavioural feature matrix")
            st.dataframe(trace_features, use_container_width=True, height=360)
        with right:
            st.markdown("#### IP risk analysis")
            st.dataframe(risk_df, use_container_width=True, height=360)
        st.caption("TRACE risk scores and labels are prototype behavioural indicators, not a certified security verdict.")

    # ORACLE
    with oracle_tab:
        section_heading("03 / Evidence intelligence", "ORACLE · Global evidence optimization",
                        "Select evidence across suspicious IPs while respecting the investigation budget.")
        o1, o2, o3, o4 = st.columns(4)
        o1.metric("Suspicious IPs", oracle_result["total_suspicious_ips"])
        o2.metric("Investigated IPs", oracle_result["investigated_ips"])
        o3.metric("Simulated utility", oracle_result["total_utility"])
        o4.metric("Budget consumed", oracle_result["total_cost"])

        total_budget = st.session_state.get("last_run_budget", budget)
        remaining = oracle_result.get("remaining_budget", max(0, total_budget - oracle_result["total_cost"]))
        utilization = (oracle_result["total_cost"] / total_budget * 100) if total_budget else 0
        st.markdown("#### Budget consumption")
        st.progress(min(1.0, utilization / 100) if total_budget else 0.0,
                    text=f"{oracle_result['total_cost']} / {total_budget} cost units used · {remaining} remaining")

        oracle_rows = []
        for item in oracle_result["selected_investigations"]:
            oracle_rows.append({
                "Source IP": item["source_ip"],
                "Priority": item["priority"],
                "Evidence items": len(item["selected_evidence"]),
                "Investigation cost": item["total_cost"],
                "Heuristic utility": item["total_utility"]
            })
        oracle_df = pd.DataFrame(oracle_rows)
        st.markdown("#### Selected investigations")
        if oracle_df.empty:
            st.info("No investigation was selected within the configured budget.")
        else:
            st.dataframe(oracle_df, use_container_width=True, hide_index=True)

        st.markdown("#### Evidence details")
        if not oracle_result["selected_investigations"]:
            st.caption("Increase the budget or change the simulation seed to explore selected evidence.")
        for item in oracle_result["selected_investigations"]:
            with st.expander(f"{item['source_ip']}  ·  {item['priority']} priority  ·  Cost {item['total_cost']}"):
                for evidence in item["selected_evidence"]:
                    st.markdown(f"**{evidence['evidence_type']}**")
                    st.write(evidence["description"])
                    ec1, ec2 = st.columns(2)
                    ec1.caption(f"Utility: {evidence['utility']}")
                    ec2.caption(f"Cost: {evidence['cost']}")
                    st.markdown("---")
        st.warning("Utility and evidence costs are prototype heuristics. They are not measured real-world information gain or threat-intelligence scores.")

    # LENS
    with lens_tab:
        section_heading("04 / Explainability", "LENS · Investigation reasoning",
                        "Understand why evidence was selected and how the investigation summary was calculated.")
        l1, l2, l3 = st.columns(3)
        l1.metric("Investigated IPs", lens_report["investigated_ips"])
        l2.metric("Heuristic utility", lens_report["total_utility"])
        l3.metric("Budget utilization", f"{lens_report['budget_utilization']}%")
        st.markdown("#### Decision explanations")
        if not oracle_result["selected_investigations"]:
            st.info("There are no selected investigations to explain for this budget.")
        for investigation in oracle_result["selected_investigations"]:
            explanation = explain_decision(investigation)
            with st.expander(f"{explanation['source_ip']}  ·  {explanation['risk_level']} risk"):
                q1, q2 = st.columns(2)
                q1.metric("Priority", explanation["priority"])
                q2.metric("Selected evidence", explanation["selected_evidence_count"])
                for item in explanation["explanations"]:
                    st.markdown(f"**{item['evidence_type']}**")
                    st.write(item["reason"])
                    st.caption(f"Decision: {item['selection_reason']}")
                    st.markdown("---")
        st.markdown("#### Complete investigation report")
        st.json(lens_report, expanded=False)
        st.download_button(
            "⬇  Export LENS report (JSON)",
            json.dumps(lens_report, indent=4, default=str),
            "prism_investigation_report.json",
            "application/json"
        )

    # REPLAY
    with replay_tab:
        section_heading("05 / Strategy evaluation", "REPLAY · Greedy vs global optimization",
                        "Compare the two strategies on the same synthetic investigation scenario.")
        comparison = replay_comparison["comparison"]
        greedy = comparison["GREEDY"]
        global_result = comparison["GLOBAL"]
        p1, p2, p3 = st.columns(3)
        p1.metric("Greedy utility", greedy["total_utility"])
        p2.metric("Global utility", global_result["total_utility"])
        p3.metric("Global utility uplift", f"{replay_comparison['global_utility_improvement']}%")

        comp_df = pd.DataFrame(comparison).T
        st.markdown("#### Strategy scorecard")
        st.dataframe(comp_df, use_container_width=True)

        chart_left, chart_right = st.columns(2)
        with chart_left:
            st.markdown("#### Utility comparison")
            st.bar_chart(pd.DataFrame({
                "Strategy": ["GREEDY", "GLOBAL"],
                "Utility": [greedy["total_utility"], global_result["total_utility"]]
            }).set_index("Strategy"))
        with chart_right:
            st.markdown("#### Budget utilization")
            st.bar_chart(pd.DataFrame({
                "Strategy": ["GREEDY", "GLOBAL"],
                "Budget utilization": [greedy["budget_utilization"], global_result["budget_utilization"]]
            }).set_index("Strategy"))

        st.markdown("#### Investigation sequence")
        for strategy, steps in replay_timeline.items():
            with st.expander(f"{strategy} strategy timeline", expanded=(strategy == "GLOBAL")):
                timeline_df = pd.DataFrame(steps)
                if timeline_df.empty:
                    st.caption("No investigation steps for this strategy.")
                else:
                    st.dataframe(timeline_df, use_container_width=True, hide_index=True)
                    if "step" in timeline_df.columns and "cumulative_utility" in timeline_df.columns:
                        st.line_chart(timeline_df.set_index("step")["cumulative_utility"])
        st.caption("Timeline represents the sequence of simulated investigation steps, not real-world event timestamps.")

    st.markdown('<div class="footer-note">PRISM · Synthetic Cybersecurity Investigation Platform · Hackathon Prototype</div>', unsafe_allow_html=True)

elif data_mode == "Synthetic Data":
    st.markdown("""
    <div class="prism-hero">
      <div class="prism-kicker">Ready for analysis</div>
      <div class="prism-title">Your investigation workspace is ready.</div>
      <div class="prism-subtitle">Configure a seed and investigation budget in the control panel, then run PRISM to generate a complete synthetic investigation.</div>
    </div>
    """, unsafe_allow_html=True)

    section_heading("Platform architecture", "Five connected intelligence modules",
                    "Each module contributes one stage to the investigation workflow.")
    modules = [
        ("🪞 MIRROR", "Synthetic environment", "Creates repeatable security-event scenarios."),
        ("🔍 TRACE", "Behavioural analysis", "Aggregates activity and calculates prototype risk indicators."),
        ("🧠 ORACLE", "Evidence optimization", "Allocates investigation budget across candidate evidence."),
        ("🔬 LENS", "Explainable decisions", "Shows why evidence and investigations were selected."),
        ("📊 REPLAY", "Strategy evaluation", "Compares greedy and global optimization approaches.")
    ]
    cols = st.columns(5)
    for col, (name, title, desc) in zip(cols, modules):
        with col:
            st.markdown(f'<div class="module-card"><b>{name}</b><br><span>{title}</span><br><br><span>{desc}</span></div>', unsafe_allow_html=True)

    st.info("Use the left control panel to start. PRISM currently operates on synthetic data; it is not connected to live network traffic or production security systems.")

    st.markdown('<div class="footer-note">PRISM · Proactive Reasoning and Intelligence for Security Monitoring</div>', unsafe_allow_html=True)