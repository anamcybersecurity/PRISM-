def explain_decision(investigation):

    source_ip = investigation["source_ip"]
    priority = investigation["priority"]

    selected = investigation["selected_evidence"]

    explanations = []

    if priority >= 3.0:
        risk_level = "HIGH"
    elif priority >= 1.5:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    for item in selected:

        explanations.append({
            "evidence_type": item["evidence_type"],
            "reason": item["description"],
            "utility": item["utility"],
            "cost": item["cost"],
            "selection_reason": (
                "Selected within the available investigation "
                "budget based on its heuristic utility."
            )
        })

    return {
        "source_ip": source_ip,
        "priority": priority,
        "risk_level": risk_level,
        "selected_evidence_count": len(selected),
        "explanations": explanations
    }