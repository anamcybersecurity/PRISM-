def explain_evidence(ranked_evidence, selected_evidence, budget):

    selected_ids = {
        item["evidence_id"]
        for item in selected_evidence
    }

    explanations = []

    selected_cost = sum(
        item["cost"] for item in selected_evidence
    )

    selected_groups = {
        item.get("redundancy_group", item["evidence_type"])
        for item in selected_evidence
    }

    for item in ranked_evidence:

        is_selected = item["evidence_id"] in selected_ids

        if is_selected:
            status = "SELECTED"
            reason = "Selected by the budget optimizer."

        elif item["cost"] > budget:
            status = "REJECTED"
            reason = "Evidence cost exceeds the available budget."

        elif item.get(
            "redundancy_group", item["evidence_type"]
        ) in selected_groups:
            status = "REJECTED"
            reason = "A related evidence group was already selected."

        elif selected_cost + item["cost"] > budget:
            status = "REJECTED"
            reason = "Insufficient remaining investigation budget."

        else:
            status = "NOT_SELECTED"
            reason = "Not included in the optimal evidence combination."

        explanations.append({
            "evidence_type": item["evidence_type"],
            "status": status,
            "utility": item["utility"],
            "cost": item["cost"],
            "reason": reason
        })

    return explanations