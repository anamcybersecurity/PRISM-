def generate_investigation_report(investigations, budget):

    total_cost = sum(
        item["total_cost"]
        for item in investigations
    )

    total_utility = sum(
        item["total_utility"]
        for item in investigations
    )

    report = {
        "investigated_ips": len(investigations),
        "total_budget": budget,
        "total_cost": total_cost,
        "remaining_budget": budget - total_cost,
        "total_utility": total_utility,
        "budget_utilization": round(
            (total_cost / budget) * 100, 2
        ) if budget > 0 else 0
    }

    return report


def print_investigation_report(report):

    print("\n========== PRISM LENS REPORT ==========")

    print("Investigated IPs:", report["investigated_ips"])
    print("Total Budget:", report["total_budget"])
    print("Total Cost:", report["total_cost"])
    print("Remaining Budget:", report["remaining_budget"])
    print("Total Utility:", report["total_utility"])

    print(
        "Budget Utilization:",
        str(report["budget_utilization"]) + "%"
    )

    print("\n========== END OF REPORT ==========")