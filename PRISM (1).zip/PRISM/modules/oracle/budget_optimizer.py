def optimize_budget(ranked_evidence, budget):

    n = len(ranked_evidence)

    # DP state: (used budget, selected groups)
    dp = {
        (0, frozenset()): (0, [])
    }

    for item in ranked_evidence:

        cost = item["cost"]
        utility = item["utility"]
        group = item.get("redundancy_group", item["evidence_type"])

        new_dp = dp.copy()

        for (used, groups), (score, selected) in dp.items():

            new_cost = used + cost

            if new_cost > budget:
                continue

            if group in groups:
                continue

            new_groups = groups | {group}
            new_score = score + utility
            new_selected = selected + [item]

            state = (new_cost, new_groups)

            if (
                state not in new_dp
                or new_score > new_dp[state][0]
            ):
                new_dp[state] = (
                    new_score,
                    new_selected
                )

        dp = new_dp

    best_state = max(
        dp,
        key=lambda state: dp[state][0]
    )

    selected = dp[best_state][1]

    total_cost = sum(item["cost"] for item in selected)
    total_utility = sum(item["utility"] for item in selected)

    return {
        "selected_evidence": selected,
        "total_cost": total_cost,
        "total_utility": total_utility,
        "remaining_budget": budget - total_cost
    }