def rank_evidence(evidence):

    # Evidence relationship mapping
    redundancy_groups = {
        "FAILED_LOGIN": "AUTHENTICATION_ACTIVITY",
        "HIGH_ACTIVITY": "GENERAL_ACTIVITY",
        "PORT_SCANNING": "NETWORK_RECONNAISSANCE",
        "PORT_DIVERSITY": "NETWORK_RECONNAISSANCE",
        "DATA_TRANSFER": "DATA_ACTIVITY",
        "SESSION_BEHAVIOUR": "SESSION_ACTIVITY"
    }

    ranked_evidence = []

    for item in evidence:

        utility = item["utility"]
        cost = item["cost"]

        efficiency = utility / cost if cost > 0 else 0

        ranked_item = item.copy()

        ranked_item["efficiency"] = round(efficiency, 2)

        # Identify evidence relationship
        ranked_item["redundancy_group"] = redundancy_groups.get(
            item["evidence_type"],
            "OTHER"
        )

        ranked_evidence.append(ranked_item)

    ranked_evidence.sort(
        key=lambda x: x["efficiency"],
        reverse=True
    )

    return ranked_evidence