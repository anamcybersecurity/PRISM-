import time

from modules.oracle.evidence_generator import generate_evidence
from modules.oracle.evidence_ranking import rank_evidence
from modules.oracle.budget_optimizer import optimize_budget
from modules.oracle.global_optimizer import optimize_global_budget


def prepare_investigations(events, features):

    suspicious_ips = features[
        features["label"] == "SUSPICIOUS"
    ]["source_ip"].tolist()

    investigations = []

    for source_ip in suspicious_ips:

        evidence = generate_evidence(
            events,
            features,
            source_ip
        )

        ranked = rank_evidence(evidence)

        total_utility = sum(
            item["utility"] for item in ranked
        )

        total_cost = sum(
            item["cost"] for item in ranked
        )

        priority = (
            total_utility / total_cost
            if total_cost > 0 else 0
        )

        investigations.append({
            "source_ip": source_ip,
            "evidence": ranked,
            "priority": round(priority, 2)
        })

    return investigations


def evaluate_greedy(investigations, budget):

    ordered = sorted(
        investigations,
        key=lambda x: x["priority"],
        reverse=True
    )

    remaining_budget = budget
    selected = []

    for investigation in ordered:

        result = optimize_budget(
            investigation["evidence"],
            remaining_budget
        )

        if result["selected_evidence"]:

            selected.append({
                "source_ip": investigation["source_ip"],
                "selected_evidence": result["selected_evidence"],
                "total_cost": result["total_cost"],
                "total_utility": result["total_utility"]
            })

            remaining_budget -= result["total_cost"]

    return {
        "selected_investigations": selected,
        "total_cost": budget - remaining_budget,
        "total_utility": sum(
            item["total_utility"] for item in selected
        ),
        "remaining_budget": remaining_budget
    }


def calculate_metrics(result, budget, execution_time):

    selected = result["selected_investigations"]

    investigated_ips = len(selected)

    total_cost = result["total_cost"]
    total_utility = result["total_utility"]

    return {
        "investigated_ips": investigated_ips,
        "total_cost": total_cost,
        "total_utility": total_utility,

        "budget_utilization": round(
            (total_cost / budget) * 100, 2
        ) if budget > 0 else 0,

        "average_utility": round(
            total_utility / investigated_ips, 2
        ) if investigated_ips > 0 else 0,

        "utility_per_cost": round(
            total_utility / total_cost, 2
        ) if total_cost > 0 else 0,

        "execution_time_ms": round(
            execution_time * 1000, 4
        )
    }


def evaluate_oracle(events, features, budget=20):

    investigations = prepare_investigations(
        events,
        features
    )

    # Evaluate Greedy
    start = time.perf_counter()

    greedy_result = evaluate_greedy(
        investigations,
        budget
    )

    greedy_time = time.perf_counter() - start

    # Evaluate Global Optimization
    start = time.perf_counter()

    global_result = optimize_global_budget(
        investigations,
        budget
    )

    global_time = time.perf_counter() - start

    # Calculate metrics
    greedy_metrics = calculate_metrics(
        greedy_result,
        budget,
        greedy_time
    )

    global_metrics = calculate_metrics(
        global_result,
        budget,
        global_time
    )

    improvement = (
        (
            global_metrics["total_utility"]
            - greedy_metrics["total_utility"]
        )
        / greedy_metrics["total_utility"]
    ) * 100 if greedy_metrics["total_utility"] > 0 else 0

    return {
        "total_suspicious_ips": len(investigations),
        "budget": budget,
        "greedy": greedy_metrics,
        "global": global_metrics,
        "utility_improvement_percent": round(improvement, 2)
    }