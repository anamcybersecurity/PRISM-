from modules.oracle.evidence_generator import generate_evidence
from modules.oracle.evidence_ranking import rank_evidence
from modules.oracle.budget_optimizer import optimize_budget
from modules.oracle.global_optimizer import optimize_global_budget


def run_oracle(events, features, source_ip, budget=5):

    evidence = generate_evidence(
        events,
        features,
        source_ip
    )

    ranked_evidence = rank_evidence(evidence)

    optimization = optimize_budget(
        ranked_evidence,
        budget
    )

    return {
        "source_ip": source_ip,
        "budget": budget,
        "total_evidence": len(evidence),
        "ranked_evidence": ranked_evidence,
        "selected_evidence": optimization["selected_evidence"],
        "total_cost": optimization["total_cost"],
        "total_utility": optimization["total_utility"],
        "remaining_budget": optimization["remaining_budget"]
    }


def run_multi_ip_oracle(events, features, budget=20):

    suspicious_ips = features[
        features["label"] == "SUSPICIOUS"
    ]["source_ip"].tolist()

    investigations = []

    for source_ip in suspicious_ips:

        evidence = generate_evidence(
            events,
            features,
            source_ip
        )

        ranked = rank_evidence(evidence)

        total_utility = sum(
            item["utility"] for item in ranked
        )

        total_cost = sum(
            item["cost"] for item in ranked
        )

        priority = (
            total_utility / total_cost
            if total_cost > 0 else 0
        )

        investigations.append({
            "source_ip": source_ip,
            "evidence": ranked,
            "priority": round(priority, 2)
        })

    # Global optimization instead of greedy allocation
    result = optimize_global_budget(
        investigations,
        budget
    )

    selected = result["selected_investigations"]

    return {
        "total_suspicious_ips": len(suspicious_ips),
        "investigated_ips": len(selected),
        "selected_investigations": selected,
        "total_budget": budget,
        "remaining_budget": result["remaining_budget"],
        "total_cost": result["total_cost"],
        "total_utility": result["total_utility"]
    }