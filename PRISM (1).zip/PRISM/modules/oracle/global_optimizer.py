def optimize_global_budget(investigations, budget):

    # Generate all valid evidence combinations for each IP
    ip_options = []

    for investigation in investigations:

        evidence = investigation["evidence"]
        options = []

        n = len(evidence)

        for mask in range(1 << n):

            selected = []
            used_groups = set()

            total_cost = 0
            total_utility = 0
            valid = True

            for i in range(n):

                if mask & (1 << i):

                    item = evidence[i]

                    group = item.get(
                        "redundancy_group",
                        item["evidence_type"]
                    )

                    if group in used_groups:
                        valid = False
                        break

                    used_groups.add(group)

                    total_cost += item["cost"]
                    total_utility += item["utility"]

                    selected.append(item)

            if valid and total_cost <= budget:

                options.append({
                    "source_ip": investigation["source_ip"],
                    "priority": investigation["priority"],
                    "selected_evidence": selected,
                    "total_cost": total_cost,
                    "total_utility": total_utility
                })

        ip_options.append(options)

    # Global Dynamic Programming
    dp = {
        0: {
            "utility": 0,
            "selections": []
        }
    }

    for options in ip_options:

        new_dp = {}

        for used_budget, state in dp.items():

            for option in options:

                new_cost = used_budget + option["total_cost"]

                if new_cost > budget:
                    continue

                new_utility = (
                    state["utility"] + option["total_utility"]
                )

                new_selections = state["selections"].copy()

                if option["selected_evidence"]:
                    new_selections.append(option)

                if (
                    new_cost not in new_dp
                    or new_utility > new_dp[new_cost]["utility"]
                ):

                    new_dp[new_cost] = {
                        "utility": new_utility,
                        "selections": new_selections
                    }

        dp = new_dp

    # Select maximum utility, then lower cost on ties
    best_cost = max(
        dp,
        key=lambda cost: (dp[cost]["utility"], -cost)
    )

    best_result = dp[best_cost]

    return {
        "selected_investigations": best_result["selections"],
        "total_cost": best_cost,
        "total_utility": best_result["utility"],
        "remaining_budget": budget - best_cost
    }