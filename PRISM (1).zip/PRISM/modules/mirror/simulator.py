from modules.mirror.event_generator import generate_events


def run_simulation(total_events=1000, seed=42):

    events = generate_events(
        total_events=total_events,
        seed=seed
    )

    return events


if __name__ == "__main__":

    data = run_simulation()

    print("MIRROR 3.0 Simulation Started")

    print("Total Events:", len(data))

    print(
        "Unique IPs:",
        len(set(event["source_ip"] for event in data))
    )