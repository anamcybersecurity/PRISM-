import random
from datetime import datetime, timedelta

def generate_events(total_events=1000, seed=42):

    rng = random.Random(seed)

    events = []

    start_time = datetime.now()

    # 100 synthetic IP addresses
    ip_addresses = []

    for i in range(1, 101):

        if i <= 34:
            ip = f"192.0.2.{i}"

        elif i <= 67:
            ip = f"198.51.100.{i - 34}"

        else:
            ip = f"203.0.113.{i - 67}"

        ip_addresses.append(ip)

    # Behaviour profiles
    profiles = (
        ["NORMAL"] * 70
        + ["BRUTE_FORCE"] * 10
        + ["PORT_SCANNING"] * 8
        + ["SUSPICIOUS_ACCESS"] * 7
        + ["MIXED_ACTIVITY"] * 5
    )

    rng.shuffle(profiles)

    event_id = 1

    for ip, profile in zip(ip_addresses, profiles):

        for i in range(10):

            if profile == "NORMAL":

                event_type = rng.choice([
                    "LOGIN_SUCCESS",
                    "FILE_ACCESS"
                ])

                severity = "LOW"
                status = "SUCCESS"
                label = "NORMAL"

                destination_port = rng.choice([80, 443])
                bytes_transferred = rng.randint(100, 5000)
                session_duration = rng.randint(30, 600)

            elif profile == "BRUTE_FORCE":

                event_type = (
                    "LOGIN_FAILED" if i < 8
                    else "LOGIN_SUCCESS"
                )

                severity = "HIGH"
                status = (
                    "FAILED" if i < 8
                    else "SUCCESS"
                )

                label = "SUSPICIOUS"

                destination_port = 22
                bytes_transferred = rng.randint(50, 300)
                session_duration = rng.randint(1, 10)

            elif profile == "PORT_SCANNING":

                event_type = "PORT_SCAN"
                severity = "HIGH"
                status = "DETECTED"
                label = "SUSPICIOUS"

                destination_port = rng.randint(1, 1024)
                bytes_transferred = rng.randint(10, 100)
                session_duration = rng.randint(1, 5)

            elif profile == "SUSPICIOUS_ACCESS":

                event_type = "FILE_ACCESS"
                severity = "HIGH"
                status = "SUCCESS"
                label = "SUSPICIOUS"

                destination_port = 443
                bytes_transferred = rng.randint(10000, 50000)
                session_duration = rng.randint(1, 20)

            else:

                event_type = rng.choice([
                    "LOGIN_FAILED",
                    "PORT_SCAN",
                    "FILE_ACCESS"
                ])

                severity = "HIGH"
                status = "FAILED" if event_type == "LOGIN_FAILED" else "DETECTED"
                label = "SUSPICIOUS"

                destination_port = rng.randint(1, 1024)
                bytes_transferred = rng.randint(10, 500)
                session_duration = rng.randint(1, 15)

            event = {

                "event_id": event_id,

                "timestamp": (
                    start_time
                    + timedelta(seconds=event_id * 10)
                ),

                "source_ip": ip,

                "event_type": event_type,

                "severity": severity,

                "status": status,

                "label": label,

                "scenario": profile,

                "destination_port": destination_port,

                "bytes_transferred": bytes_transferred,

                "session_duration": session_duration

            }

            events.append(event)

            event_id += 1

    rng.shuffle(events)

    return events[:total_events]