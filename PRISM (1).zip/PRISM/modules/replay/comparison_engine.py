def compare_strategies(replay_result):

    budget = replay_result["budget"]

    comparison = {}

    for strategy, result in replay_result["strategies"].items():

        investigated = len(
            result["selected_investigations"]
        )

        cost = result["total_cost"]
        utility = result["total_utility"]

        comparison[strategy] = {
            "investigated_ips": investigated,
            "total_cost": cost,
            "total_utility": utility,

            "remaining_budget": budget - cost,

            "budget_utilization": round(
                (cost / budget) * 100, 2
            ) if budget > 0 else 0,

            "utility_per_cost": round(
                utility / cost, 2
            ) if cost > 0 else 0
        }

    greedy_utility = comparison["GREEDY"]["total_utility"]
    global_utility = comparison["GLOBAL"]["total_utility"]

    improvement = (
        (global_utility - greedy_utility)
        / greedy_utility * 100
    ) if greedy_utility > 0 else 0

    return {
        "comparison": comparison,
        "global_utility_improvement": round(improvement, 2)
    }