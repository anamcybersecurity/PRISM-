def generate_replay_timeline(replay_result):

    timeline = {}

    for strategy, result in replay_result["strategies"].items():

        cumulative_cost = 0
        cumulative_utility = 0
        steps = []

        for index, investigation in enumerate(
            result["selected_investigations"],
            start=1
        ):

            cumulative_cost += investigation["total_cost"]
            cumulative_utility += investigation["total_utility"]

            steps.append({
                "step": index,
                "source_ip": investigation["source_ip"],
                "investigation_cost": investigation["total_cost"],
                "investigation_utility": investigation["total_utility"],
                "cumulative_cost": cumulative_cost,
                "cumulative_utility": cumulative_utility
            })

        timeline[strategy] = steps

    return timeline