from modules.oracle.evaluation import prepare_investigations, evaluate_greedy
from modules.oracle.global_optimizer import optimize_global_budget


def run_replay(events, features, budget=20):

    # Prepare suspicious IP investigations
    investigations = prepare_investigations(
        events,
        features
    )

    # Strategy 1: Greedy
    greedy_result = evaluate_greedy(
        investigations,
        budget
    )

    # Strategy 2: Global Optimization
    global_result = optimize_global_budget(
        investigations,
        budget
    )

    return {
        "budget": budget,
        "total_suspicious_ips": len(investigations),
        "strategies": {
            "GREEDY": greedy_result,
            "GLOBAL": global_result
        }
    }