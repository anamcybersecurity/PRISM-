import pandas as pd

# Map common imported event names to PRISM's canonical event vocabulary.
EVENT_TYPE_ALIASES = {
    "failed_login": "LOGIN_FAILED",
    "login_failed": "LOGIN_FAILED",
    "login_failure": "LOGIN_FAILED",
    "authentication_failure": "LOGIN_FAILED",
    "successful_login": "LOGIN_SUCCESS",
    "login_success": "LOGIN_SUCCESS",
    "login_succeeded": "LOGIN_SUCCESS",
    "port_scan": "PORT_SCAN",
    "port_scanning": "PORT_SCAN",
    "file_access": "FILE_ACCESS",
}

def analyze_imported_events(events: pd.DataFrame):
    """Aggregate imported events by source IP without requiring ground-truth labels.

    Missing fields stay missing; unavailable measurements are not fabricated.
    Risk scores are prototype rule-based indicators, not security verdicts.
    """
    if events is None or events.empty:
        raise ValueError("No imported events are available for TRACE analysis.")
    if "source_ip" not in events.columns:
        raise ValueError("TRACE requires a source_ip column.")

    df = events.copy()
    df["source_ip"] = df["source_ip"].astype("string").str.strip()
    df = df[df["source_ip"].notna() & (df["source_ip"] != "")].copy()
    if df.empty:
        raise ValueError("No valid source IP values are available for TRACE analysis.")

    if "event_type" not in df.columns:
        df["event_type"] = pd.NA
    normalized_types = df["event_type"].astype("string").str.strip().str.lower()
    df["trace_event_type"] = normalized_types.map(EVENT_TYPE_ALIASES).fillna(
        normalized_types.str.upper()
    )

    for col in ["destination_port", "bytes_transferred", "session_duration"]:
        if col not in df.columns:
            df[col] = pd.NA
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if "timestamp" in df.columns:
        df["trace_timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
        df = df.sort_values(["source_ip", "trace_timestamp"], na_position="last")
        df["time_difference"] = (
            df.groupby("source_ip")["trace_timestamp"].diff().dt.total_seconds()
        )
    else:
        df["time_difference"] = pd.NA

    features = df.groupby("source_ip", dropna=True).agg(
        total_events=("source_ip", "size"),
        failed_logins=("trace_event_type", lambda x: int((x == "LOGIN_FAILED").sum())),
        successful_logins=("trace_event_type", lambda x: int((x == "LOGIN_SUCCESS").sum())),
        port_scans=("trace_event_type", lambda x: int((x == "PORT_SCAN").sum())),
        file_access=("trace_event_type", lambda x: int((x == "FILE_ACCESS").sum())),
        unique_ports=("destination_port", "nunique"),
        avg_session_duration=("session_duration", "mean"),
        avg_bytes_transferred=("bytes_transferred", "mean"),
        total_bytes_transferred=("bytes_transferred", "sum"),
        avg_time_between_events=("time_difference", "mean"),
    ).reset_index()

    recognized = features[["failed_logins", "port_scans", "file_access"]].sum(axis=1)
    features["supported_behaviour_events"] = recognized
    features["trace_data_status"] = recognized.map(
        lambda n: "ANALYZABLE" if n > 0 else "LIMITED EVENT TYPES"
    )

    scores = []
    for _, row in features.iterrows():
        score = (
            min(int(row["failed_logins"]) * 8, 50)
            + min(int(row["port_scans"]) * 10, 40)
            + min(int(row["file_access"]) * 5, 25)
        )
        score = min(score, 100)
        if row["supported_behaviour_events"] == 0:
            risk = "INSUFFICIENT DATA"
        elif score >= 60:
            risk = "HIGH"
        elif score >= 30:
            risk = "MEDIUM"
        else:
            risk = "LOW"
        scores.append({
            "source_ip": row["source_ip"],
            "risk_score": score,
            "risk_level": risk,
            "supported_behaviour_events": int(row["supported_behaviour_events"]),
            "data_status": row["trace_data_status"],
        })

    return features, pd.DataFrame(scores)
