
import json
import pandas as pd
from io import StringIO

def load_uploaded_file(uploaded_file):
    """
    Load CSV or JSON security log files.
    Returns a Pandas DataFrame.
    """

    if uploaded_file is None:
        raise ValueError("No file was uploaded.")

    filename = uploaded_file.name.lower()

    try:
        if filename.endswith(".csv"):
            df = pd.read_csv(uploaded_file)

        elif filename.endswith(".json"):
            content = json.load(uploaded_file)

            if isinstance(content, list):
                df = pd.DataFrame(content)

            elif isinstance(content, dict):
                if isinstance(content.get("events"), list):
                    df = pd.DataFrame(content["events"])
                else:
                    df = pd.DataFrame([content])

        else:
            raise ValueError(
                "Only CSV and JSON files are supported."
            )

    except (ValueError, json.JSONDecodeError):
        raise
    except Exception as error:
        raise ValueError(
            f"Unable to read file: {error}"
        )

    if df.empty:
        raise ValueError("Uploaded file contains no records.")

    return df