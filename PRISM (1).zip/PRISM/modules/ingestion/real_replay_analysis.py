from typing import Dict, List, Any


def _summarize(selected: List[dict], budget: int, method: str) -> dict:
    total_cost = sum(int(x["cost"]) for x in selected)
    total_utility = sum(int(x["utility"]) for x in selected)
    investigations = {}
    for item in selected:
        ip = item["source_ip"]
        investigations.setdefault(ip, []).append(item)
    timeline = []
    cumulative_cost = 0
    cumulative_utility = 0
    for step, item in enumerate(selected, start=1):
        cumulative_cost += int(item["cost"])
        cumulative_utility += int(item["utility"])
        timeline.append({
            "step": step,
            "source_ip": item["source_ip"],
            "evidence_type": item["evidence_type"],
            "cost": int(item["cost"]),
            "utility": int(item["utility"]),
            "cumulative_cost": cumulative_cost,
            "cumulative_utility": cumulative_utility,
        })
    return {
        "strategy": method,
        "selected_evidence": selected,
        "investigated_ips": len(investigations),
        "evidence_items": len(selected),
        "total_cost": total_cost,
        "remaining_budget": max(0, budget - total_cost),
        "total_utility": total_utility,
        "budget_utilization": round(total_cost / budget * 100, 2) if budget else 0.0,
        "timeline": timeline,
    }


def run_imported_replay(oracle_result: dict) -> dict:
    """Compare greedy utility/cost selection with ORACLE's global 0/1-knapsack result."""
    if not isinstance(oracle_result, dict):
        raise ValueError("Run imported ORACLE before REPLAY.")
    pool = oracle_result.get("evidence_pool", [])
    budget = max(0, int(oracle_result.get("total_budget", 0)))
    if not pool:
        empty = _summarize([], budget, "GREEDY")
        global_result = _summarize([], budget, "GLOBAL")
        return {
            "comparison": {"GREEDY": empty, "GLOBAL": global_result},
            "global_utility_improvement": 0.0,
            "note": "No eligible evidence was generated from the imported records.",
        }

    # Greedy baseline: rank by utility per cost, then utility, then risk score.
    ranked = sorted(
        pool,
        key=lambda x: (
            -(float(x["utility"]) / max(1, int(x["cost"]))),
            -int(x["utility"]),
            -int(x.get("risk_score", 0)),
        ),
    )
    greedy_selected = []
    spent = 0
    for item in ranked:
        cost = int(item["cost"])
        if spent + cost <= budget:
            greedy_selected.append(item)
            spent += cost

    # Global strategy: the exact selected set returned by the 0/1 knapsack optimizer.
    global_selected = []
    for investigation in oracle_result.get("selected_investigations", []):
        for evidence in investigation.get("selected_evidence", []):
            global_selected.append({
                "source_ip": investigation["source_ip"],
                "priority": investigation.get("priority", "UNRANKED"),
                "risk_score": investigation.get("risk_score", 0),
                **evidence,
            })

    greedy = _summarize(greedy_selected, budget, "GREEDY")
    global_result = _summarize(global_selected, budget, "GLOBAL")
    uplift = (
        round((global_result["total_utility"] - greedy["total_utility"])
              / greedy["total_utility"] * 100, 2)
        if greedy["total_utility"] else 0.0
    )
    return {
        "comparison": {"GREEDY": greedy, "GLOBAL": global_result},
        "global_utility_improvement": uplift,
        "note": (
            "Greedy is a utility-per-cost baseline. GLOBAL reuses ORACLE's exact "
            "0/1-knapsack selection. Utility and cost are prototype heuristics."
        ),
    }
