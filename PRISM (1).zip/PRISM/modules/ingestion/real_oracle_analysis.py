import pandas as pd


def run_imported_oracle(features: pd.DataFrame, risk_results: pd.DataFrame,
                        events: pd.DataFrame, budget: int = 20) -> dict:
    """
    Budget-aware evidence selection for imported logs.

    Candidate IPs are derived from TRACE rule-based indicators, never from
    fabricated ground-truth labels. Evidence is generated only when the
    corresponding source measurements/events are available.
    Utility and cost are prototype heuristics, not measured threat scores.
    """
    if features is None or features.empty or risk_results is None or risk_results.empty:
        raise ValueError("Run imported TRACE analysis before ORACLE.")
    if events is None or events.empty:
        raise ValueError("Imported event records are unavailable.")
    if "source_ip" not in features or "source_ip" not in risk_results:
        raise ValueError("TRACE output must contain source_ip.")

    budget = max(0, int(budget))
    risk_lookup = risk_results.set_index("source_ip").to_dict("index")
    evidence_pool = []

    # Check whether optional source fields were actually populated.
    has_bytes = "bytes_transferred" in events.columns and events["bytes_transferred"].notna().any()
    has_duration = "session_duration" in events.columns and events["session_duration"].notna().any()
    has_ports = "destination_port" in events.columns and events["destination_port"].notna().any()

    for _, row in features.iterrows():
        ip = str(row["source_ip"])
        risk = risk_lookup.get(ip, {})
        risk_level = risk.get("risk_level", "INSUFFICIENT DATA")
        risk_score = int(risk.get("risk_score", 0) or 0)

        # Only IPs with recognized TRACE behaviour become candidates.
        if risk_score <= 0:
            continue

        candidates = []
        failed = int(row.get("failed_logins", 0) or 0)
        scans = int(row.get("port_scans", 0) or 0)
        file_access = int(row.get("file_access", 0) or 0)

        if failed > 0:
            candidates.append(("FAILED_LOGIN", f"{failed} failed-login event(s) observed for {ip}.",
                               min(10, 4 + failed), 2))
        if scans > 0:
            candidates.append(("PORT_SCANNING", f"{scans} port-scan event(s) observed for {ip}.",
                               min(10, 5 + scans), 3))
        if file_access > 0:
            candidates.append(("FILE_ACCESS", f"{file_access} file-access event(s) observed for {ip}.",
                               min(10, 3 + file_access), 2))

        ip_events = events[events["source_ip"].astype(str).str.strip() == ip]

        if has_ports:
            ports = pd.to_numeric(ip_events["destination_port"], errors="coerce").dropna().nunique()
            if ports >= 3:
                candidates.append(("PORT_DIVERSITY", f"{int(ports)} distinct destination ports observed.",
                                   min(10, 4 + int(ports)), 2))
        if has_bytes:
            total_bytes = pd.to_numeric(ip_events["bytes_transferred"], errors="coerce").sum(min_count=1)
            if pd.notna(total_bytes) and total_bytes > 50000:
                candidates.append(("DATA_TRANSFER", f"{int(total_bytes)} bytes recorded for this source IP.",
                                   7, 4))
        if has_duration:
            durations = pd.to_numeric(ip_events["session_duration"], errors="coerce").dropna()
            if not durations.empty and durations.mean() < 5:
                candidates.append(("SHORT_SESSION", f"Mean recorded session duration is {durations.mean():.2f} seconds.",
                                   5, 2))
        total_events = int(row.get("total_events", 0) or 0)
        if total_events >= 10:
            candidates.append(("HIGH_ACTIVITY", f"{total_events} events recorded for this source IP.",
                               6, 3))

        for evidence_type, description, utility, cost in candidates:
            evidence_pool.append({
                "source_ip": ip,
                "priority": "HIGH" if risk_level == "HIGH" else ("MEDIUM" if risk_level == "MEDIUM" else "LOW"),
                "risk_score": risk_score,
                "evidence_type": evidence_type,
                "description": description,
                "utility": int(utility),
                "cost": int(cost),
            })

    # 0/1 knapsack DP: maximize heuristic utility without exceeding budget.
    dp = [0] * (budget + 1)
    take = [[False] * (budget + 1) for _ in range(len(evidence_pool))]
    for i, item in enumerate(evidence_pool):
        cost, utility = item["cost"], item["utility"]
        for cap in range(budget, cost - 1, -1):
            candidate_value = dp[cap - cost] + utility
            if candidate_value > dp[cap]:
                dp[cap] = candidate_value
                take[i][cap] = True

    selected_indices = []
    cap = budget
    for i in range(len(evidence_pool) - 1, -1, -1):
        if take[i][cap]:
            selected_indices.append(i)
            cap -= evidence_pool[i]["cost"]
    selected_indices.reverse()
    selected = [evidence_pool[i] for i in selected_indices]

    grouped = {}
    for item in selected:
        ip = item["source_ip"]
        grouped.setdefault(ip, {
            "source_ip": ip,
            "priority": item["priority"],
            "risk_score": item["risk_score"],
            "selected_evidence": [],
            "total_cost": 0,
            "total_utility": 0,
        })
        grouped[ip]["selected_evidence"].append({
            "evidence_type": item["evidence_type"],
            "description": item["description"],
            "utility": item["utility"],
            "cost": item["cost"],
        })
        grouped[ip]["total_cost"] += item["cost"]
        grouped[ip]["total_utility"] += item["utility"]

    selected_investigations = sorted(
        grouped.values(), key=lambda x: (-x["total_utility"], -x["risk_score"])
    )
    total_cost = sum(item["cost"] for item in selected)
    total_utility = sum(item["utility"] for item in selected)
    return {
        "candidate_ips": int(sum(1 for _, r in risk_lookup.items()
                                 if int(r.get("risk_score", 0) or 0) > 0)),
        "investigated_ips": len(selected_investigations),
        "selected_investigations": selected_investigations,
        "evidence_pool": evidence_pool,
        "total_budget": budget,
        "remaining_budget": budget - total_cost,
        "total_cost": total_cost,
        "total_utility": total_utility,
        "budget_utilization": round(total_cost / budget * 100, 2) if budget else 0.0,
        "selection_method": "0/1 knapsack dynamic programming",
        "utility_note": "Prototype heuristic utility; not measured real-world information gain.",
    }
