
import pandas as pd

COLUMN_ALIASES = {
    "timestamp": ["timestamp", "time", "@timestamp"],
    "source_ip": ["source_ip", "src_ip", "src", "ip_address"],
    "event_type": ["event_type", "event", "activity"],
    "severity": ["severity", "level"],
    "destination_port": [
        "destination_port", "dest_port", "dst_port"
    ],
    "bytes_transferred": [
        "bytes_transferred", "bytes", "network_bytes"
    ],
    "session_duration": [
        "session_duration", "duration"
    ],
    "status": ["status", "action", "result"]
}

def normalize_events(df):

    df = df.copy()

    # Standardize column names
    df.columns = [
        str(column).strip().lower()
        for column in df.columns
    ]

    rename_columns = {}

    for standard_name, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in df.columns:
                rename_columns[alias] = standard_name
                break

    df = df.rename(columns=rename_columns)

    # Required field
    if "source_ip" not in df.columns:
        raise ValueError(
            "Missing source IP column. "
            "Expected source_ip, src_ip or src."
        )

    # Add optional fields when unavailable
    optional_fields = [
        "timestamp",
        "event_type",
        "severity",
        "destination_port",
        "bytes_transferred",
        "session_duration",
        "status"
    ]

    for field in optional_fields:
        if field not in df.columns:
            df[field] = None

    # Validate source IP
    df["source_ip"] = df["source_ip"].astype("string").str.strip()

    df = df[
        df["source_ip"].notna()
        & (df["source_ip"] != "")
    ].copy()

    # Convert numeric fields safely
    for field in [
        "destination_port",
        "bytes_transferred",
        "session_duration"
    ]:
        df[field] = pd.to_numeric(
            df[field], errors="coerce"
        )

    # Standard timestamp conversion
    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        errors="coerce",
        utc=True
    )

    # Add PRISM event IDs
    df["event_id"] = [
        f"REAL-{i:05d}"
        for i in range(1, len(df) + 1)
    ]

    # Mark imported records
    df["data_source"] = "IMPORTED"

    return df.reset_index(drop=True)