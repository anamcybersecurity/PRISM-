import pandas as pd

from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


class PRISMAnomalyDetector:

    def __init__(self):

        self.scaler = StandardScaler()

        self.model = IsolationForest(
            n_estimators=200,
            contamination=0.30,
            random_state=42
        )

        self.feature_columns = [
            "total_events",
            "failed_logins",
            "successful_logins",
            "port_scans",
            "file_access",
            "unique_ports",
            "avg_session_duration",
            "avg_bytes_transferred",
            "total_bytes_transferred",
            "avg_time_between_events"
        ]

    def fit(self, features):

        X = features[self.feature_columns]

        X_scaled = self.scaler.fit_transform(X)

        self.model.fit(X_scaled)

        return self

    def predict(self, features):

        X = features[self.feature_columns]

        X_scaled = self.scaler.transform(X)

        predictions = self.model.predict(X_scaled)

        anomaly_scores = self.model.decision_function(X_scaled)

        results = features[["source_ip"]].copy()

        results["prediction"] = [
            "ANOMALY" if p == -1 else "NORMAL"
            for p in predictions
        ]

        results["anomaly_score"] = anomaly_scores

        return results