import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)


def evaluate_model(features, predictions):

    actual = (
        features["label"] == "SUSPICIOUS"
    ).astype(int)

    predicted = (
        predictions["prediction"] == "ANOMALY"
    ).astype(int)

    accuracy = accuracy_score(actual, predicted)

    precision = precision_score(
        actual,
        predicted,
        zero_division=0
    )

    recall = recall_score(
        actual,
        predicted,
        zero_division=0
    )

    f1 = f1_score(
        actual,
        predicted,
        zero_division=0
    )

    matrix = confusion_matrix(
        actual,
        predicted,
        labels=[0, 1]
    )

    report = classification_report(
        actual,
        predicted,
        target_names=["NORMAL", "SUSPICIOUS"],
        zero_division=0
    )

    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
        "confusion_matrix": matrix,
        "classification_report": report
    }