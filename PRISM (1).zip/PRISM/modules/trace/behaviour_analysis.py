def calculate_risk(features):

    scores = []

    for _, row in features.iterrows():

        score = 0

        score += min(row["failed_logins"] * 8, 50)

        score += min(row["port_scans"] * 10, 40)

        score += min(row["file_access"] * 5, 25)

        score = min(score, 100)

        if score >= 60:
            risk = "HIGH"

        elif score >= 30:
            risk = "MEDIUM"

        else:
            risk = "LOW"

        scores.append({
            "source_ip": row["source_ip"],
            "risk_score": score,
            "risk_level": risk
        })

    return scores