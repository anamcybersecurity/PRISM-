import pandas as pd


def extract_features(events):

    df = pd.DataFrame(events)

    if df.empty:
        raise ValueError("No events available for feature extraction.")

    df["timestamp"] = pd.to_datetime(df["timestamp"])

    df = df.sort_values(
        ["source_ip", "timestamp"]
    )

    # Calculate time difference between consecutive events
    df["time_difference"] = (
        df.groupby("source_ip")["timestamp"]
        .diff()
        .dt.total_seconds()
    )

    # Aggregate behavioural features for each IP
    features = df.groupby("source_ip").agg(

        total_events=("event_id", "count"),

        failed_logins=(
            "event_type",
            lambda x: (x == "LOGIN_FAILED").sum()
        ),

        successful_logins=(
            "event_type",
            lambda x: (x == "LOGIN_SUCCESS").sum()
        ),

        port_scans=(
            "event_type",
            lambda x: (x == "PORT_SCAN").sum()
        ),

        file_access=(
            "event_type",
            lambda x: (x == "FILE_ACCESS").sum()
        ),

        unique_ports=(
            "destination_port",
            "nunique"
        ),

        avg_session_duration=(
            "session_duration",
            "mean"
        ),

        avg_bytes_transferred=(
            "bytes_transferred",
            "mean"
        ),

        total_bytes_transferred=(
            "bytes_transferred",
            "sum"
        ),

        avg_time_between_events=(
            "time_difference",
            "mean"
        )

    ).reset_index()

    # Handle missing time differences
    features["avg_time_between_events"] = (
        features["avg_time_between_events"].fillna(0)
    )

    # Preserve ground-truth labels for evaluation only

    labels = df.groupby("source_ip").agg(
    label=("label", "first")
    ).reset_index()

    features = features.merge(
    labels,
    on="source_ip",
    how="left"
    )

    return features