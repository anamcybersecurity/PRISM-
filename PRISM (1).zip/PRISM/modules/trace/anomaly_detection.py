from modules.trace.feature_extraction import extract_features

from modules.trace.behaviour_analysis import calculate_risk


def analyze_events(events):

    features = extract_features(events)

    results = calculate_risk(features)

    return features, results